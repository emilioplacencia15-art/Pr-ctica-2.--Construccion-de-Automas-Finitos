/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package com.mycompany.lenguajes.IGU;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import java.io.File;
import javax.swing.JFileChooser;

public class Simulador extends javax.swing.JFrame{

    Lienzo lienzo; 

    String modo = "nada";

    public Simulador() {
        initComponents();
        lienzo = new Lienzo();

        jPanel1.setLayout(new BorderLayout());
        jPanel1.add(lienzo, BorderLayout.CENTER);
          jButton5.addActionListener(e -> abrirTestAutomata());
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();
        jButton6 = new javax.swing.JButton();
        jButton7 = new javax.swing.JButton();
        jButton8 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jButton1.setText("Estados");
        jButton1.addActionListener(this::jButton1ActionPerformed);

        jButton2.setText("Seleccionar");
        jButton2.addActionListener(this::jButton2ActionPerformed);

        jButton3.setText("Transicion");
        jButton3.addActionListener(this::jButton3ActionPerformed);

        jButton4.setText("Eliminar");
        jButton4.addActionListener(this::jButton4ActionPerformed);

        jButton5.setText("Test");

        jButton6.setText("Tabla de transiciones");
        jButton6.addActionListener(this::jButton6ActionPerformed);

        jButton7.setText("Importar");
        jButton7.addActionListener(this::jButton7ActionPerformed);

        jButton8.setText("Exportar");
        jButton8.addActionListener(this::jButton8ActionPerformed);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jButton2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 92, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jButton3)
                .addGap(12, 12, 12)
                .addComponent(jButton4)
                .addGap(18, 18, 18)
                .addComponent(jButton5)
                .addGap(18, 18, 18)
                .addComponent(jButton6)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jButton7)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 14, Short.MAX_VALUE)
                .addComponent(jButton8)
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(11, 11, 11)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton2)
                    .addComponent(jButton1)
                    .addComponent(jButton3)
                    .addComponent(jButton4)
                    .addComponent(jButton5)
                    .addComponent(jButton6)
                    .addComponent(jButton7)
                    .addComponent(jButton8))
                .addContainerGap(266, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
       lienzo.modo = "estado";
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
       lienzo.modo = "nada";
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
    lienzo.modo = "transicion";        // TODO add your handling code here:
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
    lienzo.modo = "eliminar";        // TODO add your handling code here:
    }//GEN-LAST:event_jButton4ActionPerformed

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed
      Estado inicial = lienzo.estados.stream().filter(s -> s.esInicial).findFirst().orElse(null);
    Automata aut = new Automata(lienzo.estados, lienzo.transiciones, inicial);
    new Transiciones(aut, lienzo);   
    }//GEN-LAST:event_jButton6ActionPerformed

    private void jButton7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton7ActionPerformed
   JFileChooser fc = new JFileChooser();
        fc.addChoosableFileFilter(new javax.swing.filechooser.FileNameExtensionFilter("Archivos de Autómata (JSON, XML, JFF)", "json", "xml", "jff"));

        if (fc.showOpenDialog(this) == JFileChooser.APPROVE_OPTION) {
            File file = fc.getSelectedFile();
            try {
                Automata aut = null;
                String name = file.getName().toLowerCase();

                if (name.endsWith(".json")) {
                    aut = IOAutomata.importarJSON(file);
                } else if (name.endsWith(".jff") || name.endsWith(".xml")) {
                    // Intento inteligente: Primero probamos formato JFLAP, si falla, probamos el tuyo
                    try {
                        aut = IOAutomata.importarJFF(file);
                    } catch (Exception e) {
                        aut = IOAutomata.importarXML(file);
                    }
                }

                if (aut != null) {
                    lienzo.estados = aut.estados;
                    lienzo.transiciones = aut.transiciones;
                    lienzo.repaint();
                    JOptionPane.showMessageDialog(this, "Archivo cargado correctamente");
                }
            } catch (Exception e) {
                JOptionPane.showMessageDialog(this, "Error al importar: " + e.getMessage());
                e.printStackTrace();
            }
        }
    }//GEN-LAST:event_jButton7ActionPerformed

    private void jButton8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton8ActionPerformed
          JFileChooser fc = new JFileChooser();
        fc.addChoosableFileFilter(new javax.swing.filechooser.FileNameExtensionFilter("JSON", "json"));
        fc.addChoosableFileFilter(new javax.swing.filechooser.FileNameExtensionFilter("XML Genérico", "xml"));
        fc.addChoosableFileFilter(new javax.swing.filechooser.FileNameExtensionFilter("JFLAP (.jff)", "jff"));
        fc.setAcceptAllFileFilterUsed(false);

        if (fc.showSaveDialog(this) == JFileChooser.APPROVE_OPTION) {
            File file = fc.getSelectedFile();
            String desc = fc.getFileFilter().getDescription();
            String ext = desc.contains("JSON") ? "json" : (desc.contains("JFLAP") ? "jff" : "xml");

            if (!file.getName().toLowerCase().endsWith("." + ext)) {
                file = new File(file.getAbsolutePath() + "." + ext);
            }

            try {
                Estado inicial = lienzo.estados.stream().filter(s -> s.esInicial).findFirst().orElse(null);
                Automata aut = new Automata(lienzo.estados, lienzo.transiciones, inicial);

                switch (ext) {
                    case "json": IOAutomata.exportarJSON(aut, file); break;
                    case "xml": IOAutomata.exportarXML(aut, file); break;
                    case "jff": IOAutomata.exportarJFF(aut, file); break;
                }
                JOptionPane.showMessageDialog(this, "Exportado exitosamente como " + ext.toUpperCase());
            } catch (Exception e) {
                JOptionPane.showMessageDialog(this, "Error al exportar: " + e.getMessage());
            }
        }
    }//GEN-LAST:event_jButton8ActionPerformed

    
    public static void main(String args[]) {
        
        java.awt.EventQueue.invokeLater(() -> new Simulador().setVisible(true));
    }
    private void abrirTestAutomata() {
    if (lienzo.estados.isEmpty()) {
        JOptionPane.showMessageDialog(this, "No hay estados en el autómata");
        return;
    }

    Estado inicial = null;
    for (Estado s : lienzo.estados) {
        if (s.esInicial) { 
            inicial = s; 
            break; 
        }
    }

    if (inicial == null) {
        JOptionPane.showMessageDialog(this, "No hay estado inicial definido");
        return;
    }

    Automata aut = new Automata(lienzo.estados, lienzo.transiciones, inicial);
    TestAutomataFrame frame = new TestAutomataFrame(aut);

    frame.agregarFila();
}
   

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JButton jButton7;
    private javax.swing.JButton jButton8;
    private javax.swing.JPanel jPanel1;
    // End of variables declaration//GEN-END:variables
}
