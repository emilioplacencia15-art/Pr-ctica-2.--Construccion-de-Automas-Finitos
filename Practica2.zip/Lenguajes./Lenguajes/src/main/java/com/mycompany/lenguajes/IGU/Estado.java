/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.lenguajes.IGU;
public class Estado {
    int x, y;
     public String nombre;
    public boolean esInicial = false;
    public boolean esFinal = false;

    public Estado(int x, int y, String nombre) {
        this.x = x;
        this.y = y;
        this.nombre = nombre;
    }
    public Estado(String nombre) {
    this.x = 0;
    this.y = 0;  
    this.nombre = nombre;
}
}