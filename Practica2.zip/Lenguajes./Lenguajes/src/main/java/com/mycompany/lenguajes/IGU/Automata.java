package com.mycompany.lenguajes.IGU;

import java.util.ArrayList;

public class Automata {
    public ArrayList<Estado> estados;
    public ArrayList<Transicion> transiciones;
    public Estado estadoInicial;

    public Automata(ArrayList<Estado> estados, ArrayList<Transicion> transiciones, Estado inicial) {
        this.estados = estados;
        this.transiciones = transiciones;
        this.estadoInicial = inicial;
    }

    public boolean verificarCadena(String cadena) {
        if (estadoInicial == null) return false;
        Estado actual = estadoInicial;

        for (int i = 0; i < cadena.length(); i++) {
            String letra = String.valueOf(cadena.charAt(i));
            boolean encontrada = false;

            for (Transicion t : transiciones) {
                if (t.origen == actual && t.simbolo.equals(letra)) {
                    actual = t.destino;
                    encontrada = true;
                    break;
                }
            }

            if (!encontrada) return false;
        }

        return actual.esFinal;
    }
}