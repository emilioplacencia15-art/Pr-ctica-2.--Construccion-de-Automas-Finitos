package com.mycompany.lenguajes.IGU;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.awt.geom.QuadCurve2D;

public class Lienzo extends JPanel {

    ArrayList<Estado> estados = new ArrayList<>();
    ArrayList<Transicion> transiciones = new ArrayList<>();
    Estado seleccionado = null;
    Estado arrastrando = null;
    int offsetX, offsetY;
    int contador = 0;
    String modo = "nada";
public Lienzo(Automata automata) {
    this.estados = new ArrayList<>();
    this.transiciones = new ArrayList<>();

    for (Estado e : automata.estados) {
        
        this.estados.add(new Estado(e.x, e.y, e.nombre));
    }
    for (Transicion t : automata.transiciones) {
        Estado origen = this.estados.stream().filter(s -> s.nombre.equals(t.origen.nombre)).findFirst().orElse(null);
        Estado destino = this.estados.stream().filter(s -> s.nombre.equals(t.destino.nombre)).findFirst().orElse(null);
        if (origen != null && destino != null) {
            this.transiciones.add(new Transicion(origen, destino, t.simbolo));
        }
    }

    setBackground(Color.WHITE);
}
    public Lienzo() {
        setBackground(Color.WHITE);

        addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                Estado eSeleccionado = getEstadoEn(e.getX(), e.getY());
                if (eSeleccionado != null && modo.equals("nada")) {
                    arrastrando = eSeleccionado;
                    offsetX = e.getX() - eSeleccionado.x;
                    offsetY = e.getY() - eSeleccionado.y;
                }
            }

            @Override
            public void mouseReleased(MouseEvent e) {
                arrastrando = null;
            }

            @Override
            public void mouseClicked(MouseEvent e) {
                if (SwingUtilities.isLeftMouseButton(e) && modo.equals("estado")) {
                    estados.add(new Estado(e.getX(), e.getY(), "q" + contador++));
                    repaint();
                }
if (SwingUtilities.isRightMouseButton(e)) {
    Estado estado = getEstadoEn(e.getX(), e.getY());
    if (estado != null) {
        String[] opciones = {"Inicial", "Final", "Nada"};
        String opcion = (String) JOptionPane.showInputDialog(
                null,
                "Asignar estado:",
                "Opciones",
                JOptionPane.QUESTION_MESSAGE,
                null,
                opciones,
                opciones[2] 
        );

        if ("Inicial".equals(opcion)) {
            
            for (Estado s : estados) s.esInicial = false;
            estado.esInicial = true;
        } else if ("Final".equals(opcion)) {
           
            estado.esFinal = !estado.esFinal;
        } else if ("Nada".equals(opcion)) {
           
            estado.esInicial = false;
            estado.esFinal = false;
        }

        repaint();
    }
}

               
                if (SwingUtilities.isLeftMouseButton(e) && modo.equals("eliminar")) {
                    Estado estadoClickeado = getEstadoEn(e.getX(), e.getY());
                    if (estadoClickeado != null) {
                        estados.remove(estadoClickeado);
                        transiciones.removeIf(t -> t.origen == estadoClickeado || t.destino == estadoClickeado);
                    } else {
                        Transicion t = getTransicionEn(e.getX(), e.getY());
                        if (t != null) transiciones.remove(t);
                    }
                    repaint();
                }
                if (SwingUtilities.isLeftMouseButton(e) && modo.equals("transicion")) {
    Estado clickeado = getEstadoEn(e.getX(), e.getY());
    if (clickeado != null) {
        if (seleccionado == null) {
            seleccionado = clickeado; 
        } else {
            String simbolo = JOptionPane.showInputDialog(
                null,
                "Ingresa el símbolo:",
                "Transición",
                JOptionPane.QUESTION_MESSAGE
            );
            if (simbolo != null && !simbolo.isEmpty()) {
                transiciones.add(new Transicion(seleccionado, clickeado, simbolo));
            }
            seleccionado = null;
            repaint();
        }
    }
}
            }
        });

        addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseDragged(MouseEvent e) {
                if (arrastrando != null) {
                    arrastrando.x = e.getX() - offsetX;
                    arrastrando.y = e.getY() - offsetY;
                    repaint();
                }
            }
        });
    }

    public Estado getEstadoEn(int x, int y) {
        for (Estado e : estados) {
            if (x >= e.x && x <= e.x + 50 &&
                y >= e.y && y <= e.y + 50) {
                return e;
            }
        }
        return null;
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g;

        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
                RenderingHints.VALUE_ANTIALIAS_ON);

        for (Estado e : estados) {
            ArrayList<Transicion> loops = new ArrayList<>();
            for (Transicion t : transiciones) {
                if (t.origen == e && t.destino == e) loops.add(t);
            }
            if (!loops.isEmpty()) dibujarLoop(g2, e, loops);
        }

        ArrayList<Transicion> yaDibujadas = new ArrayList<>();
        for (Transicion t : transiciones) {
            if (t.origen == t.destino || yaDibujadas.contains(t)) continue;

            ArrayList<Transicion> grupo = new ArrayList<>();
            for (Transicion otra : transiciones) {
                if (otra.origen == t.origen && otra.destino == t.destino) {
                    grupo.add(otra);
                    yaDibujadas.add(otra);
                }
            }
            dibujarLineaAgrupada(g2, grupo);
        }

       
        for (Estado e : estados) {
           
            g2.setColor(Color.WHITE);
            g2.fillOval(e.x, e.y, 50, 50);
            g2.setColor(Color.BLACK);
            g2.setStroke(new BasicStroke(2));
            g2.drawOval(e.x, e.y, 50, 50);

            if (e.esFinal) g2.drawOval(e.x + 5, e.y + 5, 40, 40);

            if (e.esInicial) {
                int[] xPoints = {e.x - 15, e.x - 5, e.x - 15};
                int[] yPoints = {e.y + 20, e.y + 25, e.y + 30};
                g2.fillPolygon(xPoints, yPoints, 3);
            }

            
            g2.drawString(e.nombre, e.x + 18, e.y + 30);
        }
    }

    private void dibujarFlecha(Graphics2D g2, int x1, int y1, int x2, int y2) {
        double dx = x2 - x1, dy = y2 - y1;
        double angulo = Math.atan2(dy, dx);
        int largo = 12;
        int xF1 = (int) (x2 - largo * Math.cos(angulo - Math.PI / 6));
        int yF1 = (int) (y2 - largo * Math.sin(angulo - Math.PI / 6));
        int xF2 = (int) (x2 - largo * Math.cos(angulo + Math.PI / 6));
        int yF2 = (int) (y2 - largo * Math.sin(angulo + Math.PI / 6));
        g2.setStroke(new BasicStroke(2));
        g2.drawLine(x2, y2, xF1, yF1);
        g2.drawLine(x2, y2, xF2, yF2);
    }

    private void dibujarLoop(Graphics2D g2, Estado e, ArrayList<Transicion> loops) {
        int cx = e.x + 25, cy = e.y + 25, radio = 20;
        g2.drawArc(cx - radio, cy - 50, radio * 2, radio * 2, 0, 180);

        StringBuilder texto = new StringBuilder();
        for (int i = 0; i < loops.size(); i++) {
            texto.append(loops.get(i).simbolo);
            if (i < loops.size() - 1) texto.append(",");
        }
        FontMetrics fm = g2.getFontMetrics();
        int ancho = fm.stringWidth(texto.toString());
        g2.drawString(texto.toString(), cx - ancho / 2, cy - 55);

        int px = cx + radio, py = cy - 40;
        g2.drawLine(px, py, px - 5, py - 10);
        g2.drawLine(px, py, px + 5, py - 10);
    }

    private void dibujarLineaAgrupada(Graphics2D g2, ArrayList<Transicion> grupo) {
        Transicion t = grupo.get(0);
        int r = 25;
        int x1 = t.origen.x + r, y1 = t.origen.y + r;
        int x2 = t.destino.x + r, y2 = t.destino.y + r;
        double dx = x2 - x1, dy = y2 - y1, dist = Math.sqrt(dx*dx + dy*dy);
        if (dist == 0) return;

        int xInicio = (int)(x1 + (dx/dist)*r);
        int yInicio = (int)(y1 + (dy/dist)*r);
        int xFin = (int)(x2 - (dx/dist)*r);
        int yFin = (int)(y2 - (dy/dist)*r);

        boolean bidireccional = false;
        for (Transicion otra : transiciones) {
            if (otra.origen == t.destino && otra.destino == t.origen) { bidireccional = true; break; }
        }

        int cx, cy;
        if (bidireccional) {
            double offset = 40, nx = -dy/dist, ny = dx/dist;
            cx = (int)((xInicio + xFin)/2 + nx*offset);
            cy = (int)((yInicio + yFin)/2 + ny*offset);
            QuadCurve2D curva = new QuadCurve2D.Float(xInicio, yInicio, cx, cy, xFin, yFin);
            g2.draw(curva);
            dibujarFlecha(g2, cx, cy, xFin, yFin);
        } else {
            g2.drawLine(xInicio, yInicio, xFin, yFin);
            dibujarFlecha(g2, xInicio, yInicio, xFin, yFin);
            cx = (xInicio + xFin)/2;
            cy = (yInicio + yFin)/2;
        }

        StringBuilder texto = new StringBuilder();
        for (int i = 0; i < grupo.size(); i++) {
            texto.append(grupo.get(i).simbolo);
            if (i < grupo.size()-1) texto.append(",");
        }
        FontMetrics fm = g2.getFontMetrics();
        int ancho = fm.stringWidth(texto.toString());
        g2.drawString(texto.toString(), cx - ancho/2, cy - 5);
    }

    private Transicion getTransicionEn(int x, int y) {
        for (Transicion t : transiciones) {
            int x1 = t.origen.x + 25, y1 = t.origen.y + 25;
            int x2 = t.destino.x + 25, y2 = t.destino.y + 25;
            double dist = distanciaPuntoLinea(x, y, x1, y1, x2, y2);
            if (dist < 10) return t;
        }
        return null;
    }

    private double distanciaPuntoLinea(int px, int py, int x1, int y1, int x2, int y2) {
        double A = px - x1, B = py - y1, C = x2 - x1, D = y2 - y1;
        double dot = A*C + B*D, len_sq = C*C + D*D;
        double param = dot / len_sq;
        double xx, yy;
        if (param < 0) { xx = x1; yy = y1; }
        else if (param > 1) { xx = x2; yy = y2; }
        else { xx = x1 + param*C; yy = y1 + param*D; }
        double dx = px - xx, dy = py - yy;
        return Math.sqrt(dx*dx + dy*dy);
    }
    public static void mostrarAutomata(Automata automata) {
    JFrame frame = new JFrame("Autómata Generado");
    frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    frame.add(new Lienzo(automata));
    frame.setSize(800, 600);
    frame.setLocationRelativeTo(null);
    frame.setVisible(true);
}
}